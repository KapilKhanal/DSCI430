Random number generator
