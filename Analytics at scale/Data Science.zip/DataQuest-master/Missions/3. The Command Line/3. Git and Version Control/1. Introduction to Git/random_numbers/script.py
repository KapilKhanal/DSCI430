import random
if __name__ == "__main__":
    print(random.randint(0,10))
