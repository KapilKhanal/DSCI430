import random
for i in range(100):
    print(random.randint(1,10))

