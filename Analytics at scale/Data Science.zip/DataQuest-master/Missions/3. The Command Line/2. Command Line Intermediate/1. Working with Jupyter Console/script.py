if __name__ == "__main__":
	print("This is a Python script")

print("Excellent!")
s = 8

