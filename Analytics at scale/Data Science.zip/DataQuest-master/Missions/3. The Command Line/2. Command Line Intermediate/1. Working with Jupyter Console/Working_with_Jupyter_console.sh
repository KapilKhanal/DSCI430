#!/bin/bash

###################
#ipython

# dq = 5

# dq_10 = dq * 10

# dq?

# help()

# exit
###################
#ipython

# %run script.py

# %who

# exit

###################
#ipython

# %cpaste

#for i in range(10):
#    if i < 5:
#        print(i)
#    else:
#       print(i * 2)

# exit

##################
