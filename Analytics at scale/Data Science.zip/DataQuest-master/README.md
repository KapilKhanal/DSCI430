# DataQuest
## Data Science track
Missions, Challenges and Projects on:
1. Python Introduction
2. Data Analysis and Visualisation
3. The Command Line
4. Working with Data Sources
5. Probability and Statistics
6. Machine Learning
7. Advanced Python and Computer Science
8. Advaced topics in Data Science
9. Working with large Datasets
